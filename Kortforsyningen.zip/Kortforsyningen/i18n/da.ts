<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>Kortforsyningen</name>
    <message>
        <location filename="kortforsyningen.py" line="288"/>
        <source>Kortforsyningen</source>
        <translation>Kortforsyningen</translation>
    </message>
    <message>
        <location filename="kortforsyningen.py" line="102"/>
        <source>No contact to Kortforsyningen</source>
        <translation>Ingen kontakt til Kortforsyningen</translation>
    </message>
    <message>
        <location filename="kortforsyningen.py" line="134"/>
        <source>No contact to Kortforsyningen</source>
        <translation>Ingen kontakt til Kortforsyningen</translation>
    </message>
    <message>
        <location filename="kortforsyningen.py" line="324"/>
        <source>Settings</source>
        <translation>Indstillinger</translation>
    </message>
    <message>
        <location filename="kortforsyningen.py" line="270"/>
        <source>Error</source>
        <translation>Fejl</translation>
    </message>
    <message>
        <location filename="kortforsyningen.py" line="270"/>
        <source>Could not load the layer. Is username and password correct?</source>
        <translation>Kunne ikke indlæse laget. Er brugernavn og password korrekte?</translation>
    </message>
    <message>
        <location filename="kortforsyningen.py" line="333"/>
        <source>About the plugin</source>
        <translation>Om pluginet</translation>
    </message>
    <message>
        <location filename="kortforsyningen.py" line="242"/>
        <source>Please, fill out username and password</source>
        <translation>Udfyld venligst brugernavn og kodeord.</translation>
    </message>
    <message>
        <location filename="kf_settings.ui" line="42"/>
        <source>Username</source>
        <translation>Brugernavn</translation>
    </message>
</context>
<context>
  <name>s</name>
    <message>
        <location filename="kf_settings.ui" line="14"/>
        <source>Access to Kortforsyningen.dk</source>
        <translation>Adgang til Kortforsyningen.dk</translation>
    </message>
    <message>
        <location filename="kf_settings.ui" line="42"/>
        <source>Username</source>
        <translation>Brugernavn</translation>
    </message>
    <message>
        <location filename="kf_settings.ui" line="55"/>
        <source>Password</source>
        <translation>Kodeord</translation>
    </message>
    <message>
        <location filename="kf_settings.ui" line="68"/>
        <source>Remember settings</source>
        <translation>Gem indstillinger</translation>
    </message>
</context>
<context>
  <name>Dialog</name>
    <message>
        <location filename="aboutKortforsyningen.ui" line="22"/>
        <source>About the plugin</source>
        <translation>Om pluginet</translation>
    </message>
</context>
</TS>
